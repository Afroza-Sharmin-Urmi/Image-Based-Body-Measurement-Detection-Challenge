# body measurement > 2023-09-20 1:07am
https://universe.roboflow.com/urmi/body-measurement-zmbgv

Provided by a Roboflow user
License: CC BY 4.0

